  
<section class="section-login wf-section">
    <div class="container-login">
      <h1 id="header-paywall" class="centered-heading" >You're Close To Unlocking Exclusive Content</h1>
      <p id="subheader-paywall" class="centered-subheading" >Unlock Content With Link Below</p>
      <div id="lockpay" class="container-2 w-container">
        <a target="_self" id="paylink" button="email" href="#" class="purchase w-button" >🔑 Acquire Membership Here</a>
      </div>
    </div>
  </section>
  
  