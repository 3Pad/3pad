
<section class="section-login wf-section">
    <div class="container-login">
      <h1 id="header-login" class="centered-heading">Login To View Exclusive Content</h1>
      <p id="subheader-login" class="centered-subheading" >Choose A Option Below To Login</p>
      <div id="lockpay" class="container-2 w-container">
        <div class="columns w-row">
          <div class="column w-col w-col-3 w-col-small-small-stack w-col-tiny-tiny-stack">
            <a target="_self" id="unlocklink" button="email" href="#" class="email-login w-button" >📧 Login With Email</a>
          </div>
          <div class="column-2 w-col w-col-3 w-col-small-small-stack w-col-tiny-tiny-stack">
            <a target="_self" id="unlocklink" button="nft" href="#" class="loginwithnft w-button" >🤳 Login With NFT</a>
          </div>
          <div class="column-3 w-col w-col-3 w-col-small-small-stack w-col-tiny-tiny-stack">
            <a target="_self" id="unlocklink" button="crypto" href="#" class="cryptologin w-button" >₿ Login With Crypto</a>
          </div>
          <div class="column-4 w-col w-col-3 w-col-small-small-stack w-col-tiny-tiny-stack">
            <a target="_self" id="unlocklink" button="pass" href="#" class="b4 w-button">🎟️  Login With Pass</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  