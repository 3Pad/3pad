<!-- Clicky tag (.js) -->
<script async src=" //static.getclicky.com/<?php $settings_page = get_queried_object_id(); echo get_field('clicky_analytics', $settings_page); ?>.js"></script>