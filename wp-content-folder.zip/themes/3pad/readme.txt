Make Sure To Define WP - Config Variables. Add statements to wp-config file

////Moralis KEY
define('MORALIS_API_KEY', 'ENTER_KEY');

// IPFS PATH
define('IPFS_PATH', 'ENTER_PATH');

//GIT PUSH SECONDS
define('GIT_PUSH_SECONDS', 'ENTER_SECONDS');